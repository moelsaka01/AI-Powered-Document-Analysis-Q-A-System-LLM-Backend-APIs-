# AI-powered Document Q&A API

This project is a minimal but complete example of an AI-powered document analysis and question answering backend.

It lets you:
- Upload text or PDF documents
- Automatically split them into chunks and embed them
- Store embeddings in a local vector store (Chroma)
- Ask natural language questions and get answers grounded in the uploaded docs
- Use a FastAPI backend with async endpoints and a simple healthcheck

You can use it as a portfolio project to demonstrate:
- Python backend development
- FastAPI and async APIs
- RAG (Retrieval Augmented Generation) patterns
- Basic vector search and document chunking
- Clean project structure and tests

## Features

- FastAPI backend with:
  - `/health` - healthcheck endpoint
  - `/documents` - upload documents (plain text in this version)
  - `/query` - ask questions about the uploaded documents
- Chroma DB for local vector storage
- OpenAI embeddings and chat completions (can be swapped for another provider)
- Pydantic models for request/response validation
- Simple chunking and retrieval logic
- Basic tests

## Tech stack

- Python 3.11+
- FastAPI
- Uvicorn
- OpenAI Python client
- ChromaDB
- Pydantic
- Pytest

## Project structure

```text
ai_doc_qa_project/
  app/
    __init__.py
    config.py
    models.py
    services/
      __init__.py
      embedding_service.py
      vector_store.py
      qa_service.py
    routes/
      __init__.py
      documents.py
      query.py
      health.py
    main.py
  tests/
    __init__.py
    test_health.py
    test_documents_and_query.py
  requirements.txt
  README.md
```

## Getting started

### 1. Clone the repo

```bash
git clone <your-fork-url>.git
cd ai_doc_qa_project
```

### 2. Create a virtual environment

```bash
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure environment

Create a `.env` file in the project root:

```env
OPENAI_API_KEY=your_real_key_here
EMBEDDING_MODEL=text-embedding-3-small
CHAT_MODEL=gpt-4o-mini
CHROMA_DIR=./chroma_store
```

For local testing without OpenAI configured, the code will still import successfully, but calls to the OpenAI APIs will fail until you provide a valid key.

### 5. Run the API

```bash
uvicorn app.main:app --reload
```

The API will be available at: http://127.0.0.1:8000

Interactive docs: http://127.0.0.1:8000/docs

### 6. Example usage

#### Upload a document

```bash
curl -X POST "http://127.0.0.1:8000/documents" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Sample doc",
    "text": "FastAPI is a modern, fast web framework for building APIs with Python..."
  }'
```

#### Ask a question

```bash
curl -X POST "http://127.0.0.1:8000/query" \
  -H "Content-Type: application/json" \
  -d '{
    "question": "What is FastAPI?",
    "top_k": 3
  }'
```

Response example:

```json
{
  "answer": "FastAPI is a modern, fast web framework for building APIs with Python.",
  "sources": [
    {
      "document_id": "some-uuid",
      "chunk": "FastAPI is a modern, fast web framework for building APIs with Python...",
      "score": 0.12
    }
  ]
}
```

### 7. Run tests

```bash
pytest
```

This will run basic health and flow tests to ensure the project is wired correctly.

## Notes

- This is a simplified educational project, not a production system.
- For a real deployment, you would want:
  - Authentication and rate limiting
  - Better chunking and document preprocessing
  - More robust error handling and logging
  - Persistent and scalable vector storage
  - Proper secrets management
