import os
import pytest
from fastapi.testclient import TestClient
from app.main import app


pytestmark = pytest.mark.skip(
    reason="Integration test that calls OpenAI. Enable when OPENAI_API_KEY is configured."
)

client = TestClient(app)


def test_document_upload_and_query_flow():
    os.environ.setdefault("OPENAI_API_KEY", "dummy")

    doc_payload = {
        "title": "FastAPI intro",
        "text": "FastAPI is a modern, fast web framework for building APIs with Python."
    }
    create_resp = client.post("/documents", json=doc_payload)
    assert create_resp.status_code == 201
    doc = create_resp.json()
    assert "id" in doc

    q_payload = {"question": "What is FastAPI?", "top_k": 3}
    query_resp = client.post("/query", json=q_payload)
    assert query_resp.status_code == 200
    body = query_resp.json()
    assert "answer" in body
    assert isinstance(body.get("sources"), list)
