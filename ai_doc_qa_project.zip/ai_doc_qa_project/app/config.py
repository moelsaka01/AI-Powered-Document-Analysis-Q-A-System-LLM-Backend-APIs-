from functools import lru_cache
from pydantic import BaseModel


class Settings(BaseModel):
    OPENAI_API_KEY: str = "changeme"
    EMBEDDING_MODEL: str = "text-embedding-3-small"
    CHAT_MODEL: str = "gpt-4o-mini"
    CHROMA_DIR: str = "./chroma_store"
    COLLECTION_NAME: str = "documents"


@lru_cache
def get_settings() -> Settings:
    return Settings()
