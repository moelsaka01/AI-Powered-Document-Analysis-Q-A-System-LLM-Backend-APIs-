from pydantic import BaseModel, Field
from typing import List, Optional
from uuid import UUID, uuid4


class DocumentIn(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    text: str = Field(..., min_length=1)


class DocumentChunk(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    document_id: UUID
    text: str
    order: int


class DocumentOut(BaseModel):
    id: UUID
    title: str


class QueryRequest(BaseModel):
    question: str = Field(..., min_length=1)
    top_k: int = Field(default=5, ge=1, le=20)


class SourceChunk(BaseModel):
    document_id: UUID
    chunk: str
    score: float


class QueryResponse(BaseModel):
    answer: str
    sources: List[SourceChunk] = []


class HealthResponse(BaseModel):
    status: str = "ok"
    detail: Optional[str] = None
