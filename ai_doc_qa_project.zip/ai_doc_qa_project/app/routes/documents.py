from uuid import uuid4
from typing import List

from fastapi import APIRouter, HTTPException, status

from app.models import DocumentIn, DocumentOut, DocumentChunk
from app.services.embedding_service import EmbeddingService
from app.services.vector_store import VectorStore

router = APIRouter()

DOCUMENTS: dict = {}
CHUNKS: List[DocumentChunk] = []


def chunk_text(text: str, max_chars: int = 600) -> List[str]:
    words = text.split()
    chunks = []
    current = []
    current_len = 0
    for w in words:
        if current_len + len(w) + 1 > max_chars and current:
            chunks.append(" ".join(current))
            current = [w]
            current_len = len(w)
        else:
            current.append(w)
            current_len += len(w) + 1
    if current:
        chunks.append(" ".join(current))
    return chunks


@router.post("/documents", response_model=DocumentOut, status_code=status.HTTP_201_CREATED)
async def create_document(doc: DocumentIn) -> DocumentOut:
    doc_id = uuid4()
    DOCUMENTS[str(doc_id)] = {"id": doc_id, "title": doc.title}

    raw_chunks = chunk_text(doc.text)
    if not raw_chunks:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Document text could not be chunked.",
        )

    chunks: List[DocumentChunk] = []
    for order, text in enumerate(raw_chunks):
        chunks.append(
            DocumentChunk(
                document_id=doc_id,
                text=text,
                order=order,
            )
        )

    CHUNKS.extend(chunks)

    embed_service = EmbeddingService()
    store = VectorStore()

    embeddings = embed_service.embed_texts([c.text for c in chunks])
    metadatas = [
        {"document_id": str(c.document_id), "text": c.text, "order": c.order}
        for c in chunks
    ]
    ids = [str(c.id) for c in chunks]
    store.add_embeddings(embeddings, metadatas, ids)

    return DocumentOut(id=doc_id, title=doc.title)
