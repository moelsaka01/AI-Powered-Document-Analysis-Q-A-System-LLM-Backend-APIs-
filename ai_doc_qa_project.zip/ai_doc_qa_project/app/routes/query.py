from typing import List
from uuid import UUID

from fastapi import APIRouter, HTTPException, status

from app.models import QueryRequest, QueryResponse, SourceChunk
from app.services.embedding_service import EmbeddingService
from app.services.vector_store import VectorStore
from app.services.qa_service import QAService

router = APIRouter()


@router.post("/query", response_model=QueryResponse)
async def query_docs(payload: QueryRequest) -> QueryResponse:
    if not payload.question.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Question can not be empty.",
        )

    embed_service = EmbeddingService()
    store = VectorStore()
    qa = QAService()

    q_embedding = embed_service.embed_texts([payload.question])[0]
    ids, metadatas, scores = store.query(q_embedding, payload.top_k)
    sources: List[SourceChunk] = []
    for meta, score in zip(metadatas, scores):
        try:
            doc_id = UUID(meta.get("document_id"))
        except Exception:
            continue
        sources.append(
            SourceChunk(
                document_id=doc_id,
                chunk=meta.get("text", ""),
                score=score,
            )
        )

    answer = qa.answer_question(payload.question, sources)
    return QueryResponse(answer=answer, sources=sources)
