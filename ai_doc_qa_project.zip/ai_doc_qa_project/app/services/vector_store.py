from typing import List, Tuple
from uuid import UUID
import chromadb
from chromadb.config import Settings as ChromaSettings
from app.config import get_settings


class VectorStore:
    def __init__(self) -> None:
        settings = get_settings()
        self.client = chromadb.PersistentClient(
            path=settings.CHROMA_DIR,
            settings=ChromaSettings(allow_reset=False),
        )
        self.collection = self.client.get_or_create_collection(
            name=settings.COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"},
        )

    def add_embeddings(
        self,
        embeddings: List[List[float]],
        metadatas: List[dict],
        ids: List[str],
    ) -> None:
        if not embeddings:
            return
        self.collection.add(
            embeddings=embeddings,
            metadatas=metadatas,
            ids=ids,
        )

    def query(
        self,
        embedding: List[float],
        top_k: int,
    ) -> Tuple[List[str], List[dict], List[float]]:
        if not embedding:
            return [], [], []
        res = self.collection.query(
            query_embeddings=[embedding],
            n_results=top_k,
        )
        ids = res.get("ids", [[]])[0]
        metadatas = res.get("metadatas", [[]])[0]
        distances = res.get("distances", [[]])[0]
        scores = [float(d) for d in distances]
        return ids, metadatas, scores
