from typing import List
from uuid import UUID
from openai import OpenAI
from app.config import get_settings
from app.models import SourceChunk


class QAService:
    def __init__(self) -> None:
        settings = get_settings()
        self.client = OpenAI(api_key=settings.OPENAI_API_KEY)
        self.model = settings.CHAT_MODEL

    def build_context(self, sources: List[SourceChunk]) -> str:
        if not sources:
            return "No relevant context found in the documents."
        parts = []
        for src in sources:
            parts.append(f"Document {src.document_id}: {src.chunk}")
        return "\n\n".join(parts)

    def answer_question(self, question: str, sources: List[SourceChunk]) -> str:
        context = self.build_context(sources)
        system_prompt = (
            "You are a helpful assistant that answers questions based only on the provided context. "
            "If the answer is not in the context, say you do not know."
        )
        user_prompt = f"Context:\n{context}\n\nQuestion: {question}"
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.2,
        )
        return response.choices[0].message.content or ""
